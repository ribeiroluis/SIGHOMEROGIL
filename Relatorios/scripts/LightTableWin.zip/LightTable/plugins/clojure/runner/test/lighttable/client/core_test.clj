(ns lighttable.client.core-test
  (:use clojure.test
        client.core))

(deftest a-test
  (testing "FIXME, I fail."
    (is (= 0 1))))
