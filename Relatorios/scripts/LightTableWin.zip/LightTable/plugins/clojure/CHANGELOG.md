#Changes

##0.0.3

* ADDED: Make hints async to remove the weird slow downs on eval.

##0.0.2

* FIX: left out some behaviors needed for the remote nrepl connections
