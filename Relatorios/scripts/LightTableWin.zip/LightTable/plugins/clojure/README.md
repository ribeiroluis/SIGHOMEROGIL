##Clojure for Light Table

The official Clojure language plugin for Light Table.

###License

Copyright (C) 2013 Kodowa Inc.

Distributed under the EPL, see license.md for the full text.