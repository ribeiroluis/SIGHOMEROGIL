(defproject com.lighttable/javascript "0.0.1"
  :description "Rainbow parens plugin for Light Table"
  :dependencies [[org.clojure/clojure "1.5.1"]])
