##Changes

###0.0.3

* FIX: ipython connections in Python 3
