##Rainbow parens for Light Table

A CLJS implementation of Rainbow parens for Light Table.

###License

Copyright (C) 2013 Kodowa Inc.

Distributed under the GPLv3, see license.md for the full text.